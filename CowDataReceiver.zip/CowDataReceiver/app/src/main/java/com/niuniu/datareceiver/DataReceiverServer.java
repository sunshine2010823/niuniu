package com.niuniu.datareceiver;

import android.content.Context;
import android.util.Log;
import fi.iki.elonen.NanoHTTPD;
import org.json.JSONObject;
import java.io.IOException;

public class DataReceiverServer extends NanoHTTPD {
    private static final int PORT = 8080;
    private Context context;
    private DatabaseHelper dbHelper;

    public DataReceiverServer(Context context) {
        super(PORT);
        this.context = context;
        this.dbHelper = new DatabaseHelper(context);
    }

    @Override
    public Response serve(IHTTPSession session) {
        String uri = session.getUri();
        if ("/sync".equals(uri) && Method.POST.equals(session.getMethod())) {
            try {
                StringBuilder sb = new StringBuilder();
                session.parseBody(sb);
                String body = sb.toString();
                JSONObject json = new JSONObject(body);
                String username = json.optString("username", "unknown");
                String time = json.optString("time", "");
                int meters = json.optInt("meters", 0);
                String deviceId = json.optString("deviceId", "");
                
                dbHelper.insertRecord(username, time, meters, deviceId);
                return newFixedLengthResponse(Response.Status.OK, "application/json", "{\"status\":\"ok\"}");
            } catch (Exception e) {
                e.printStackTrace();
                return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "Error: " + e.getMessage());
            }
        }
        return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not Found");
    }

    public void startServer() {
        try {
            start(NanoHTTPD.SOCKET_READ_TIMEOUT, false);
            Log.d("Server", "Server started on port " + PORT);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void stopServer() {
        stop();
    }
}