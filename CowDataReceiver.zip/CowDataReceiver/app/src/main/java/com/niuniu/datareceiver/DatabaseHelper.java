package com.niuniu.datareceiver;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "cow_data.db";
    private static final int DB_VERSION = 1;
    public static final String TABLE_NAME = "records";
    public static final String COL_ID = "_id";
    public static final String COL_USERNAME = "username";
    public static final String COL_TIME = "time";
    public static final String COL_METERS = "meters";
    public static final String COL_DEVICE_ID = "device_id";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT, " +
                COL_TIME + " TEXT, " +
                COL_METERS + " INTEGER, " +
                COL_DEVICE_ID + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void insertRecord(String username, String time, int meters, String deviceId) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_TIME, time);
        values.put(COL_METERS, meters);
        values.put(COL_DEVICE_ID, deviceId);
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public List<Record> getAllRecords() {
        List<Record> records = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, null, null, null, null, null, COL_ID + " DESC");
        while (cursor.moveToNext()) {
            Record r = new Record();
            r.id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ID));
            r.username = cursor.getString(cursor.getColumnIndexOrThrow(COL_USERNAME));
            r.time = cursor.getString(cursor.getColumnIndexOrThrow(COL_TIME));
            r.meters = cursor.getInt(cursor.getColumnIndexOrThrow(COL_METERS));
            r.deviceId = cursor.getString(cursor.getColumnIndexOrThrow(COL_DEVICE_ID));
            records.add(r);
        }
        cursor.close();
        db.close();
        return records;
    }

    public static class Record {
        public int id;
        public String username;
        public String time;
        public int meters;
        public String deviceId;
    }
}