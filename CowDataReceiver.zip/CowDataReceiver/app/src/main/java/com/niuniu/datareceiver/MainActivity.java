package com.niuniu.datareceiver;

import android.Manifest;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.text.format.Formatter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TextView tvIp;
    private Button btnStart, btnStop, btnRefresh;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> dataList;
    private DataReceiverServer server;
    private DatabaseHelper dbHelper;
    private static final int PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        tvIp = findViewById(R.id.tvIp);
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);
        btnRefresh = findViewById(R.id.btnRefresh);
        listView = findViewById(R.id.listView);
        
        dataList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataList);
        listView.setAdapter(adapter);
        
        dbHelper = new DatabaseHelper(this);
        
        checkPermissions();
        refreshDataList();
        
        btnStart.setOnClickListener(v -> startServer());
        btnStop.setOnClickListener(v -> stopServer());
        btnRefresh.setOnClickListener(v -> refreshDataList());
        
        // 显示本机IP
        displayIpAddress();
    }
    
    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_WIFI_STATE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_WIFI_STATE},
                        PERMISSION_REQUEST_CODE);
            }
        }
    }
    
    private void displayIpAddress() {
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        String ip = Formatter.formatIpAddress(wm.getConnectionInfo().getIpAddress());
        tvIp.setText("手机IP: " + ip + " : 8080");
    }
    
    private void startServer() {
        if (server == null) {
            server = new DataReceiverServer(this);
            server.startServer();
            Toast.makeText(this, "服务器已启动", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "服务器已在运行", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void stopServer() {
        if (server != null) {
            server.stopServer();
            server = null;
            Toast.makeText(this, "服务器已停止", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void refreshDataList() {
        dataList.clear();
        List<DatabaseHelper.Record> records = dbHelper.getAllRecords();
        for (DatabaseHelper.Record r : records) {
            dataList.add(r.username + "  |  " + r.time + "  |  " + r.meters + "米");
        }
        adapter.notifyDataSetChanged();
    }
    
    @Override
    protected void onDestroy() {
        stopServer();
        super.onDestroy();
    }
}